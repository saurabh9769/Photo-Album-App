~~new_app~~ Ruby on Rails application with no name.
=======================

A quick experiment. An application to manage music albums. 

No audio file will be uploaded nor your online music library will be accessed. An album cover (an image file) can be uploaded and stored in database with its title. Images are searchable using your own keyword and each image comes with a delete button. 

It's meant to cover a few extra RESTful CRUD operations that Hartl's famous tutorial does not cover but are commonly employed by many web applications. It's built on the famous tutorial application. Therefore, the tweet functionality is still there together with the image management functionality of my own.

Another functionality will be added as I wish to take on another project in the future.

~~Work in progress~~. Complete (for now as of 2013/07/07). 

https://whispering-sierra-9871.herokuapp.com/